<template>
  <div class="box">
    <header class="header">user header</header>
    <div class="content">user content</div>
  </div>
</template>
